<?php return array (
  'livewireComponents' => 
  array (
    'App\\Filament\\Resources\\Coas\\Pages\\ManageCoas' => 'App\\Filament\\Resources\\Coas\\Pages\\ManageCoas',
    'App\\Filament\\Resources\\PaketInternets\\Pages\\ManagePaketInternets' => 'App\\Filament\\Resources\\PaketInternets\\Pages\\ManagePaketInternets',
    'App\\Filament\\Resources\\PelangganCorporates\\Pages\\ManagePelangganCorporates' => 'App\\Filament\\Resources\\PelangganCorporates\\Pages\\ManagePelangganCorporates',
    'App\\Filament\\Resources\\PelangganRetails\\Pages\\ManagePelangganRetails' => 'App\\Filament\\Resources\\PelangganRetails\\Pages\\ManagePelangganRetails',
    'App\\Filament\\Resources\\Permissions\\Pages\\ManagePermissions' => 'App\\Filament\\Resources\\Permissions\\Pages\\ManagePermissions',
    'App\\Filament\\Resources\\Purchases\\Pages\\ManagePurchases' => 'App\\Filament\\Resources\\Purchases\\Pages\\ManagePurchases',
    'App\\Filament\\Resources\\RetailInvoices\\Pages\\ManageRetailInvoices' => 'App\\Filament\\Resources\\RetailInvoices\\Pages\\ManageRetailInvoices',
    'App\\Filament\\Resources\\Roles\\Pages\\ManageRoles' => 'App\\Filament\\Resources\\Roles\\Pages\\ManageRoles',
    'App\\Filament\\Resources\\Sales\\Pages\\ManageSales' => 'App\\Filament\\Resources\\Sales\\Pages\\ManageSales',
    'App\\Filament\\Resources\\SubscriptionInvoices\\Pages\\ManageSubscriptionInvoices' => 'App\\Filament\\Resources\\SubscriptionInvoices\\Pages\\ManageSubscriptionInvoices',
    'App\\Filament\\Resources\\Transactions\\Pages\\ListTransactions' => 'App\\Filament\\Resources\\Transactions\\Pages\\ListTransactions',
    'App\\Filament\\Resources\\Users\\Pages\\ManageUsers' => 'App\\Filament\\Resources\\Users\\Pages\\ManageUsers',
    'App\\Filament\\Resources\\Vendors\\Pages\\ManageVendors' => 'App\\Filament\\Resources\\Vendors\\Pages\\ManageVendors',
    'App\\Filament\\Resources\\Wallets\\Pages\\ManageWallets' => 'App\\Filament\\Resources\\Wallets\\Pages\\ManageWallets',
    'App\\Filament\\Pages\\LaporanHutang' => 'App\\Filament\\Pages\\LaporanHutang',
    'App\\Filament\\Pages\\LaporanHutangPelanggan' => 'App\\Filament\\Pages\\LaporanHutangPelanggan',
    'App\\Filament\\Pages\\LaporanKeuangan' => 'App\\Filament\\Pages\\LaporanKeuangan',
    'App\\Filament\\Pages\\LaporanLangganan' => 'App\\Filament\\Pages\\LaporanLangganan',
    'App\\Filament\\Pages\\LaporanPembelian' => 'App\\Filament\\Pages\\LaporanPembelian',
    'App\\Filament\\Pages\\LaporanPenjualan' => 'App\\Filament\\Pages\\LaporanPenjualan',
    'App\\Filament\\Pages\\LaporanPiutang' => 'App\\Filament\\Pages\\LaporanPiutang',
    'App\\Filament\\Pages\\Settings' => 'App\\Filament\\Pages\\Settings',
    'Filament\\Pages\\Dashboard' => 'Filament\\Pages\\Dashboard',
    'App\\Filament\\Widgets\\CoaUsageChart' => 'App\\Filament\\Widgets\\CoaUsageChart',
    'App\\Filament\\Widgets\\YearlyIncomeExpenseChart' => 'App\\Filament\\Widgets\\YearlyIncomeExpenseChart',
    'Filament\\Widgets\\AccountWidget' => 'Filament\\Widgets\\AccountWidget',
    'Filament\\Widgets\\FilamentInfoWidget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'Filament\\Livewire\\DatabaseNotifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'Filament\\Auth\\Pages\\EditProfile' => 'Filament\\Auth\\Pages\\EditProfile',
    'Filament\\Livewire\\GlobalSearch' => 'Filament\\Livewire\\GlobalSearch',
    'Filament\\Livewire\\Notifications' => 'Filament\\Livewire\\Notifications',
    'Filament\\Livewire\\Sidebar' => 'Filament\\Livewire\\Sidebar',
    'Filament\\Livewire\\SimpleUserMenu' => 'Filament\\Livewire\\SimpleUserMenu',
    'Filament\\Livewire\\Topbar' => 'Filament\\Livewire\\Topbar',
    'Filament\\Auth\\Pages\\Login' => 'Filament\\Auth\\Pages\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanHutang.php' => 'App\\Filament\\Pages\\LaporanHutang',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanHutangPelanggan.php' => 'App\\Filament\\Pages\\LaporanHutangPelanggan',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanKeuangan.php' => 'App\\Filament\\Pages\\LaporanKeuangan',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanLangganan.php' => 'App\\Filament\\Pages\\LaporanLangganan',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanPembelian.php' => 'App\\Filament\\Pages\\LaporanPembelian',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanPenjualan.php' => 'App\\Filament\\Pages\\LaporanPenjualan',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\LaporanPiutang.php' => 'App\\Filament\\Pages\\LaporanPiutang',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Pages\\Settings.php' => 'App\\Filament\\Pages\\Settings',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageConfigurations' => 
  array (
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\cendana-corp\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Coas\\CoaResource.php' => 'App\\Filament\\Resources\\Coas\\CoaResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\PaketInternets\\PaketInternetResource.php' => 'App\\Filament\\Resources\\PaketInternets\\PaketInternetResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\PelangganCorporates\\PelangganCorporateResource.php' => 'App\\Filament\\Resources\\PelangganCorporates\\PelangganCorporateResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\PelangganRetails\\PelangganRetailResource.php' => 'App\\Filament\\Resources\\PelangganRetails\\PelangganRetailResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Permissions\\PermissionResource.php' => 'App\\Filament\\Resources\\Permissions\\PermissionResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Purchases\\PurchaseResource.php' => 'App\\Filament\\Resources\\Purchases\\PurchaseResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\RetailInvoices\\RetailInvoiceResource.php' => 'App\\Filament\\Resources\\RetailInvoices\\RetailInvoiceResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Roles\\RoleResource.php' => 'App\\Filament\\Resources\\Roles\\RoleResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Sales\\SaleResource.php' => 'App\\Filament\\Resources\\Sales\\SaleResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\SubscriptionInvoices\\SubscriptionInvoiceResource.php' => 'App\\Filament\\Resources\\SubscriptionInvoices\\SubscriptionInvoiceResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Transactions\\TransactionResource.php' => 'App\\Filament\\Resources\\Transactions\\TransactionResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Users\\UserResource.php' => 'App\\Filament\\Resources\\Users\\UserResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Vendors\\VendorResource.php' => 'App\\Filament\\Resources\\Vendors\\VendorResource',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Resources\\Wallets\\WalletResource.php' => 'App\\Filament\\Resources\\Wallets\\WalletResource',
  ),
  'resourceConfigurations' => 
  array (
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\cendana-corp\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Widgets\\CoaUsageChart.php' => 'App\\Filament\\Widgets\\CoaUsageChart',
    'C:\\laragon\\www\\cendana-corp\\app\\Filament\\Widgets\\YearlyIncomeExpenseChart.php' => 'App\\Filament\\Widgets\\YearlyIncomeExpenseChart',
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\cendana-corp\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);